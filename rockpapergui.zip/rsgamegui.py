from tkinter import *
import random

# Initialize scores
user_score = 0
computer_score = 0

# Main window setup
root = Tk()
root.title("Rock-Paper-Scissors Game")
root.geometry("400x450")
root.config(bg="#925e97")

# Choices list
choices = ["Rock", "Paper", "Scissors"]

# Functions
def play(user_choice):
    global user_score, computer_score

    comp_choice = random.choice(choices)
    result = ""

    if user_choice == comp_choice:
        result = "It's a tie!"
    elif (user_choice == "Rock" and comp_choice == "Scissors") or \
         (user_choice == "Scissors" and comp_choice == "Paper") or \
         (user_choice == "Paper" and comp_choice == "Rock"):
        result = "You Win!"
        user_score += 1
    else:
        result = "Computer Wins!"
        computer_score += 1

    # Update labels
    user_label.config(text=f"Your Choice: {user_choice}")
    comp_label.config(text=f"Computer's Choice: {comp_choice}")
    result_label.config(text=result)
    score_label.config(text=f"Score - You: {user_score} | Computer: {computer_score}")

# GUI Elements
Label(root, text="Rock-Paper-Scissors", font=("Helvetica", 18, "bold"), bg="#180101",fg="white").pack(pady=10)

user_label = Label(root, text="Your Choice: ", font=("Helvetica", 12), bg="#0a622e",fg="white")
user_label.pack()

comp_label = Label(root, text="Computer's Choice: ", font=("Helvetica", 12), bg="#675eb6",fg="black")
comp_label.pack()

result_label = Label(root, text="", font=("Helvetica", 14, "bold"), bg="#ebf860",fg="black")
result_label.pack(pady=10)

score_label = Label(root, text="Score - You: 0 | Computer: 0", font=("Helvetica", 12), bg="#a9c6f1",fg="black")
score_label.pack(pady=10)

# Buttons
btn_frame = Frame(root, bg="#b0e7b9")
btn_frame.pack(pady=20)

Button(btn_frame, text="Rock", width=10, command=lambda: play("Rock"),bg="pink").grid(row=0, column=0, padx=10)
Button(btn_frame, text="Paper", width=10, command=lambda: play("Paper"),bg="blue").grid(row=0, column=1, padx=10)
Button(btn_frame, text="Scissors", width=10, command=lambda: play("Scissors"),bg="orange").grid(row=0, column=2, padx=10)

# Exit button
Button(root, text="Exit Game", command=root.destroy, bg="red", fg="white", width=15).pack(pady=20)

root.mainloop()
